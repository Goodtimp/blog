<template>
  <h1>{{ headertext }}</h1>
</template>
<script>
 export default{
   data(){
     return{
     }
   },
   props:['headertext']
 }
</script>