from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = 'blog'
#app设置为中文名称,找到app下的apps.py文件 